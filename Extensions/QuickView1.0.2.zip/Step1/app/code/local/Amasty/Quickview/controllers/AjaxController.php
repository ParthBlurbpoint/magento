<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2015 Amasty (https://www.amasty.com)
 * @package Amasty_Quickview
 */
require_once Mage::getModuleDir('controllers', 'Mage_Catalog').DS.'ProductController.php';
class Amasty_Quickview_AjaxController extends Mage_Catalog_ProductController
{
}
