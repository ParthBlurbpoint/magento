<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2015 Amasty (https://www.amasty.com)
 * @package Amasty_Quickview
 */
class Amasty_Quickview_Helper_Data extends Mage_Core_Helper_Abstract
{

}
